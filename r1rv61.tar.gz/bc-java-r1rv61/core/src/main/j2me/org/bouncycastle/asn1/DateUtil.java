package org.bouncycastle.asn1;

import java.util.Date;

class DateUtil
{
    static Date epochAdjust(Date date)
    {
       return date;
    }
}
